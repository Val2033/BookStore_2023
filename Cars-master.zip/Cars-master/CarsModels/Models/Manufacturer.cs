﻿namespace CarsModels.Models
{
    public record Manufactorer
    {
        public int id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
