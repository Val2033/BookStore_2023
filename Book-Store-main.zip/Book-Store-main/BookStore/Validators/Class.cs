﻿using FluentValidation;

namespace BookStore.Validators
{
    public class Validator : AbstractValidator<Validator>
    {
        public Validator()
        {

        }
    }
}
